# ElectroIsla 360 — APK nativa híbrida

Esta versión reemplaza la TWA/Chrome visible por una Activity Android propia con WebView. Mantiene la tienda actual en GitHub Pages, por lo que productos, Supabase, carrito, pagos, zonas y WhatsApp siguen funcionando desde la web actual.

## Identidad de actualización
- Application ID: `io.github.isladelajuventud.twa`
- Versión: `9.9.1`
- Version code: `1000`
- URL: `https://isladelajuventud.github.io/ElectroIsla-App/`

**No incluir el keystore en el repositorio.** Para actualizar la APK existente debe firmarse con el mismo `signing.keystore` que ya conserva el propietario.
